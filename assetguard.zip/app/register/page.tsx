import { redirect } from "next/navigation"

export default function RegisterIndexPage() {
  redirect("/register/property")
}
