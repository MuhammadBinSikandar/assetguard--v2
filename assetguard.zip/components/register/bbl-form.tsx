"use client"

import { useState } from "react"
import { Label } from "@/components/ui/label"
import { Input } from "@/components/ui/input"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { Spinner } from "@/components/ui/spinner"

export type BBLValues = {
  borough: "Brooklyn" | "Queens" | "Manhattan" | "Bronx" | "Staten Island"
  block: string
  lot: string
}

export type PropertyData = {
  address: string
  borough: string
  block: string
  lot: string
  owner: string
  type: string
  taxClass: string
  building: {
    yearBuilt?: number | null
    stories?: number | null
    totalArea?: number | null
    commercialUnits?: number | null
    residentialUnits?: number | null
    constructionType?: string | null
  }
  land: {
    frontage?: number | null
    depth?: number | null
    landArea?: number | null
    zoning?: string | null
  }
  assessment: {
    marketValue?: number | null
    taxableValue?: number | null
    latestYear?: number | null
  }
}

export default function BBLForm({
  initialValues,
  onFetched,
}: {
  initialValues?: BBLValues
  onFetched: (values: BBLValues, data: PropertyData) => void
}) {
  const [borough, setBorough] = useState<BBLValues["borough"]>(initialValues?.borough || "Brooklyn")
  const [block, setBlock] = useState(initialValues?.block || "")
  const [lot, setLot] = useState(initialValues?.lot || "")
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState<string | null>(null)

  const disabled = !borough || !block || !lot

  const fetchProperty = async () => {
    setError(null)
    setLoading(true)
    try {
      const res = await fetch("/api/nyc/property", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ borough, block: Number(block), lot: Number(lot) }),
      })
      if (!res.ok) throw new Error("Failed to fetch property info")
      const data: PropertyData = await res.json()
      onFetched({ borough, block, lot }, data)
    } catch (e: any) {
      setError(e?.message || "Unexpected error")
    } finally {
      setLoading(false)
    }
  }

  return (
    <div className="space-y-6" aria-live="polite">
      <div className="grid gap-4 md:grid-cols-3">
        <div className="flex flex-col gap-2">
          <Label htmlFor="borough">Borough</Label>
          <Select value={borough} onValueChange={(v) => setBorough(v as BBLValues["borough"])}>
            <SelectTrigger id="borough" aria-label="Select borough">
              <SelectValue placeholder="Select borough" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="Brooklyn">Brooklyn</SelectItem>
              <SelectItem value="Queens">Queens</SelectItem>
              <SelectItem value="Manhattan">Manhattan</SelectItem>
              <SelectItem value="Bronx">Bronx</SelectItem>
              <SelectItem value="Staten Island">Staten Island</SelectItem>
            </SelectContent>
          </Select>
        </div>

        <div className="flex flex-col gap-2">
          <Label htmlFor="block">Block</Label>
          <Input
            id="block"
            inputMode="numeric"
            pattern="[0-9]*"
            value={block}
            onChange={(e) => setBlock(e.target.value.replace(/[^0-9]/g, ""))}
            placeholder="e.g., 1304"
            aria-describedby="block-hint"
          />
          <span id="block-hint" className="text-xs text-muted-foreground">
            Numeric only
          </span>
        </div>

        <div className="flex flex-col gap-2">
          <Label htmlFor="lot">Lot</Label>
          <Input
            id="lot"
            inputMode="numeric"
            pattern="[0-9]*"
            value={lot}
            onChange={(e) => setLot(e.target.value.replace(/[^0-9]/g, ""))}
            placeholder="e.g., 43"
            aria-describedby="lot-hint"
          />
          <span id="lot-hint" className="text-xs text-muted-foreground">
            Numeric only
          </span>
        </div>
      </div>

      {error && (
        <Card className="border-destructive/30">
          <CardContent className="pt-4 text-destructive text-sm">{error}</CardContent>
        </Card>
      )}

      <div className="flex items-center gap-3">
        <Button onClick={fetchProperty} disabled={disabled || loading} aria-live="polite">
          {loading ? (
            <span className="inline-flex items-center gap-2">
              <Spinner className="h-4 w-4" />
              Fetching...
            </span>
          ) : (
            "Fetch Property Info"
          )}
        </Button>
        <span className="text-sm text-muted-foreground">or use Back/Cancel to exit</span>
      </div>
    </div>
  )
}
