"use client"

import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Separator } from "@/components/ui/separator"
import type { PropertyData } from "./bbl-form"

export type { PropertyData }

export default function PropertyDetails({
  property,
  onBack,
  onContinue,
}: {
  property: PropertyData
  onBack: () => void
  onContinue: () => void
}) {
  return (
    <div className="space-y-6">
      <header>
        <h2 className="text-2xl font-bold">Property Information Retrieved</h2>
      </header>

      <Card>
        <CardHeader>
          <CardTitle className="text-base">Property</CardTitle>
        </CardHeader>
        <CardContent className="space-y-2">
          <Item label="Property Address" value={property.address} />
          <Item label="Owner" value={property.owner} />
          <Item label="Type" value={property.type} />
          <Item label="Tax Class" value={property.taxClass} />
          <Item label="Borough / Block / Lot" value={`${property.borough} / ${property.block} / ${property.lot}`} />
        </CardContent>
      </Card>

      <div className="grid gap-6 md:grid-cols-2">
        <Card>
          <CardHeader>
            <CardTitle className="text-base">Building Information</CardTitle>
          </CardHeader>
          <CardContent className="grid grid-cols-2 gap-3">
            <Item label="Year Built" value={fmt(property.building.yearBuilt)} />
            <Item label="Stories" value={fmt(property.building.stories)} />
            <Item label="Total Area" value={fmt(property.building.totalArea, " sq ft")} />
            <Item label="Commercial Units" value={fmt(property.building.commercialUnits)} />
            <Item label="Residential Units" value={fmt(property.building.residentialUnits)} />
            <Item label="Construction Type" value={property.building.constructionType || "—"} />
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle className="text-base">Land Information</CardTitle>
          </CardHeader>
          <CardContent className="grid grid-cols-2 gap-3">
            <Item label="Frontage" value={fmt(property.land.frontage, " ft")} />
            <Item label="Depth" value={fmt(property.land.depth, " ft")} />
            <Item label="Land Area" value={fmt(property.land.landArea, " sq ft")} />
            <Item label="Zoning" value={property.land.zoning || "—"} />
          </CardContent>
        </Card>
      </div>

      <Card>
        <CardHeader>
          <CardTitle className="text-base">Assessment Values</CardTitle>
        </CardHeader>
        <CardContent className="grid grid-cols-3 gap-3">
          <Item label="Market Value" value={money(property.assessment.marketValue)} />
          <Item label="Taxable Value" value={money(property.assessment.taxableValue)} />
          <Item
            label="History (Latest Year)"
            value={property.assessment.latestYear ? String(property.assessment.latestYear) : "—"}
          />
        </CardContent>
      </Card>

      <div className="flex items-center justify-end gap-2">
        <button onClick={onBack} className="text-sm text-primary underline underline-offset-4">
          Back
        </button>
        <Separator orientation="vertical" className="h-6" />
        <button
          onClick={onContinue}
          className="inline-flex items-center rounded-md bg-primary px-4 py-2 text-primary-foreground hover:opacity-90"
        >
          Continue
        </button>
      </div>
    </div>
  )
}

function Item({ label, value }: { label: string; value: string }) {
  return (
    <div className="space-y-1">
      <div className="text-xs text-muted-foreground">{label}</div>
      <div className="text-sm">{value}</div>
    </div>
  )
}

function fmt(n?: number | null, suffix = "") {
  if (n === null || n === undefined) return "—"
  return `${Intl.NumberFormat().format(n)}${suffix}`
}
function money(n?: number | null) {
  if (n === null || n === undefined) return "—"
  return Intl.NumberFormat(undefined, { style: "currency", currency: "USD", maximumFractionDigits: 0 }).format(n)
}
