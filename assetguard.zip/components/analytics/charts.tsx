"use client"

import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import {
  ResponsiveContainer,
  LineChart,
  Line,
  CartesianGrid,
  XAxis,
  YAxis,
  Tooltip,
  BarChart,
  Bar,
  Legend,
} from "recharts"

type Series = {
  valuationUSD: Array<{ ts: string; value: number }>
  registrations: Array<{ day: string; count: number }>
  transfers: Array<{ day: string; count: number }>
}

export function AnalyticsCharts({ series }: { series?: Series }) {
  const valuation = series?.valuationUSD ?? []
  const daily = mergeSeries(series?.registrations ?? [], series?.transfers ?? [])

  return (
    <section className="grid grid-cols-1 lg:grid-cols-2 gap-6">
      <Card className="h-[360px]">
        <CardHeader>
          <CardTitle>Total Asset Valuation (USD)</CardTitle>
        </CardHeader>
        <CardContent className="h-[280px]">
          <ResponsiveContainer width="100%" height="100%">
            <LineChart data={valuation}>
              <CartesianGrid strokeDasharray="3 3" />
              <XAxis dataKey="ts" />
              <YAxis />
              <Tooltip />
              <Legend />
              <Line type="monotone" dataKey="value" stroke="hsl(var(--chart-1))" name="Valuation" />
            </LineChart>
          </ResponsiveContainer>
        </CardContent>
      </Card>

      <Card className="h-[360px]">
        <CardHeader>
          <CardTitle>Registrations vs Transfers (Daily)</CardTitle>
        </CardHeader>
        <CardContent className="h-[280px]">
          <ResponsiveContainer width="100%" height="100%">
            <BarChart data={daily}>
              <CartesianGrid strokeDasharray="3 3" />
              <XAxis dataKey="day" />
              <YAxis />
              <Tooltip />
              <Legend />
              <Bar dataKey="registrations" fill="hsl(var(--chart-2))" />
              <Bar dataKey="transfers" fill="hsl(var(--chart-3))" />
            </BarChart>
          </ResponsiveContainer>
        </CardContent>
      </Card>
    </section>
  )
}

function mergeSeries(
  reg: Array<{ day: string; count: number }>,
  tr: Array<{ day: string; count: number }>,
): Array<{ day: string; registrations: number; transfers: number }> {
  const map = new Map<string, { registrations: number; transfers: number }>()
  for (const r of reg) map.set(r.day, { registrations: r.count, transfers: 0 })
  for (const t of tr) map.set(t.day, { ...(map.get(t.day) ?? { registrations: 0, transfers: 0 }), transfers: t.count })
  return Array.from(map.entries()).map(([day, v]) => ({ day, ...v }))
}

export default AnalyticsCharts
