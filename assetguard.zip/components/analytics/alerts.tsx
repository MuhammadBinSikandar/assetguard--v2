"use client"

import { useEffect, useRef, useState } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { useToast } from "@/hooks/use-toast"

type Alert = {
  id: string
  ts: string
  kind: "price-surge" | "price-drop"
  property: string
  deltaPct: number
}

export function RealTimeAlerts() {
  const { toast } = useToast()
  const [alerts, setAlerts] = useState<Alert[]>([])
  const esRef = useRef<EventSource | null>(null)

  useEffect(() => {
    const es = new EventSource("/api/analytics/events")
    esRef.current = es

    es.onmessage = (e) => {
      try {
        const alert: Alert = JSON.parse(e.data)
        setAlerts((prev) => [alert, ...prev].slice(0, 10))
        toast({
          title: alert.kind === "price-surge" ? "Price Surge" : "Price Drop",
          description: `${alert.property}: ${alert.deltaPct > 0 ? "+" : ""}${alert.deltaPct.toFixed(2)}%`,
        })
      } catch {}
    }
    es.onerror = () => {
      // leave quietly; stream will close
    }
    return () => {
      es.close()
    }
  }, [toast])

  return (
    <Card>
      <CardHeader>
        <CardTitle>Real-time Alerts</CardTitle>
      </CardHeader>
      <CardContent className="space-y-3">
        {alerts.length === 0 ? (
          <p className="text-sm text-muted-foreground">Listening for significant property changes…</p>
        ) : (
          <ul className="space-y-2">
            {alerts.map((a) => (
              <li key={a.id} className="flex items-center justify-between">
                <div className="min-w-0">
                  <div className="truncate text-sm font-medium">{a.property}</div>
                  <div className="text-xs text-muted-foreground">{new Date(a.ts).toLocaleString()}</div>
                </div>
                <Badge variant={a.kind === "price-surge" ? "default" : "destructive"}>
                  {a.kind === "price-surge" ? "Surge" : "Drop"} {a.deltaPct > 0 ? "+" : ""}
                  {a.deltaPct.toFixed(2)}%
                </Badge>
              </li>
            ))}
          </ul>
        )}
      </CardContent>
    </Card>
  )
}
